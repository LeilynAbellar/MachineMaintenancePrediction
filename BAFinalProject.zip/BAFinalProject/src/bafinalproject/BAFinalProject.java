package bafinalproject;

import weka.classifiers.Evaluation;
import weka.classifiers.lazy.IBk;
import weka.core.converters.ConverterUtils.DataSource;
import java.util.Random;
import weka.core.Instance;
import java.util.ArrayList;
import java.util.List;
import weka.classifiers.Classifier;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instances;
import java.util.Scanner; 

public class BAFinalProject {
public static void main(String[]args) throws Exception{
      DataSource source = new DataSource("predictive_maintenance.csv");
      Instances dataset = source.getDataSet();
      dataset.setClassIndex(dataset.numAttributes()-1);
          
      IBk ibk = new IBk() ;
      ibk.buildClassifier(dataset);
      System.out.println(ibk);
      Evaluation eval6 = new Evaluation(dataset);
      eval6.crossValidateModel(ibk, dataset, 10, new Random (1));
      System.out.println(eval6.toSummaryString() + "\n");
      
      DataSource newSourceTrain = new DataSource("predictive_maintenance.csv");
      Instances trainDataset = newSourceTrain.getDataSet ( ) ;
      //set class index to the last attribute
      trainDataset.setClassIndex(trainDataset.numAttributes()-1);
      
      ibk.buildClassifier(trainDataset);
      System.out.println(ibk);
      Evaluation evalModel = new Evaluation(trainDataset);
      evalModel.crossValidateModel (ibk, trainDataset, 10, new Random (1));
      System.out.println(evalModel.toSummaryString () + "\n");
      //Save Model
      weka.core.SerializationHelper.write ("my_ibk_model.model", ibk);
      
      //Load Model 
      //observe the type-casting
      IBk ibkLoadFromFile = (IBk)
      weka.core.SerializationHelper.read ("my_ibk_model.model");
   
      //load new dataset
      DataSource newSourceTest = new DataSource("predictive_maintenance.csv");
      Instances testDataset = newSourceTest.getDataSet();
      //set class index to the last attribute
      testDataset.setClassIndex(testDataset.numAttributes()-1);
      
      //get class double value for first instance
      double actualValue = testDataset.instance(10).classValue ();
      //get Instance object of first instance
      Instance newInst = testDataset.instance(10);
      
      //call classifyInstance, which returns a double value for the class
      double predIBk = ibkLoadFromFile.classifyInstance(newInst);
      
      System.out.println(actualValue + ", " + predIBk);
      
      Evaluation evalModelTest = new Evaluation(testDataset);
      evalModelTest.evaluateModel(ibkLoadFromFile, testDataset);
      System.out.println(evalModelTest.toSummaryString() + "\n");
      System.out.println(evalModelTest.toMatrixString());
           
      // we need those for creating new instances later
      final Attribute attributeAirTemp = new Attribute("AirTemperature[K]");
      final Attribute attributeProcessTemp = new Attribute("ProcessTemperature[K]");
      final Attribute attributeRotSpeed = new Attribute("RotationalSpeed[rpm]");
      final Attribute attributeTorque = new Attribute("Torque[Nm]");
      final Attribute attributeToolWear = new Attribute("ToolWear[min]");
      final List<String> classes = new ArrayList<String>() {
            {
                add("NoFailure");
                add("HeatDissipationFailure");
                add("RandomFailure");
                add("OverstrainFailure");
                add("PowerFailure");
                add("ToolWearFailure");
            }
        };
      
        // Instances(...) requires ArrayList&lt;&gt; instead of List&lt;&gt;...
       ArrayList<Attribute> attributeList = new ArrayList<Attribute>(2) {
            {
                add(attributeAirTemp);
                add(attributeProcessTemp);
                add(attributeRotSpeed);
                add(attributeTorque);
                add(attributeToolWear);
                Attribute attributeClass = new Attribute("@@class@@", classes);
                add(attributeClass);
            }
        };
        
        // unpredicted data sets (reference to sample structure for new instances)
        Instances dataUnpredicted = new Instances("TestInstances",
                attributeList, 1);
        // last feature is target variable
        dataUnpredicted.setClassIndex(dataUnpredicted.numAttributes() - 1); 

        
        DenseInstance newInstanceNoFailure = new DenseInstance(dataUnpredicted.numAttributes()) {
            {
                setValue(attributeAirTemp, 0.5);
                setValue(attributeProcessTemp, 0.5);
                setValue(attributeRotSpeed, 0.5);
                setValue(attributeTorque, 0.4);
                setValue(attributeToolWear, 0.4);
            }
        };

        DenseInstance newInstanceHeatFailure = new DenseInstance(dataUnpredicted.numAttributes()) {
            {
                setValue(attributeAirTemp, 0.9);
                setValue(attributeProcessTemp, 0.8);
                setValue(attributeRotSpeed, 0.3);
                setValue(attributeTorque, 0.8);
                setValue(attributeToolWear, 0.4);
            }
        };
        
        DenseInstance newInstanceOverstrainFailure = new DenseInstance(dataUnpredicted.numAttributes()) {
            {
                setValue(attributeAirTemp, 0.4);
                setValue(attributeProcessTemp, 0.3);
                setValue(attributeRotSpeed, 0.6);
                setValue(attributeTorque, 0.8);
                setValue(attributeToolWear, 0.9);
            }
        };
        
        DenseInstance newInstancePowerFailure = new DenseInstance(dataUnpredicted.numAttributes()) {
            {
                setValue(attributeAirTemp, 0.5);
                setValue(attributeProcessTemp, 0.6);
                setValue(attributeRotSpeed, 0.8);
                setValue(attributeTorque, 0.7);
                setValue(attributeToolWear, 0.5);
            }
        };
        
        DenseInstance newInstanceToolWearFailure = new DenseInstance(dataUnpredicted.numAttributes()) {
            {
                setValue(attributeAirTemp, 0.3);
                setValue(attributeProcessTemp, 0.3);
                setValue(attributeRotSpeed, 0.4);
                setValue(attributeTorque, 0.7);
                setValue(attributeToolWear, 0.9);
            }
        };
        
           //ask input from user
         Scanner sc = new Scanner(System.in);
         System.out.print("Air temperature [K]: ");
         double airTemp = sc.nextDouble();
         System.out.print("Process Temperature [K]: ");
         double procTemp = sc.nextDouble();
         System.out.print("Rotational Speed [rpm]: ");
         double rotSpeed = sc.nextDouble();
         System.out.print("Torque [Nm]: ");
         double torque = sc.nextDouble();
         System.out.print("Tool Wear [min]: ");
         double toolWear = sc.nextDouble();
         
         DenseInstance newInstanceUserInput = new DenseInstance(dataUnpredicted.numAttributes()) {
            {
                setValue(attributeAirTemp, airTemp);
                setValue(attributeProcessTemp, procTemp);
                setValue(attributeRotSpeed, rotSpeed);
                setValue(attributeTorque, torque);
                setValue(attributeToolWear, toolWear);
            }
        };
 
        // instance to use in prediction
        DenseInstance newInstance = newInstanceUserInput;
        // reference to dataset
        newInstance.setDataset(dataUnpredicted);
 
        // import ready trained model
        Classifier cls = ibk;
        try {
            cls = (Classifier) weka.core.SerializationHelper
                    .read("my_ibk_model.model");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (cls == null)
            return;
 
        // predict new sample
        try {
            double result = cls.classifyInstance(newInstance);
            //this will retrieve line separator dependent on OS.
            String newLine = System.getProperty("line.separator");
            System.out.println(newLine);
            System.out.println("Air temperature [K]: " + airTemp);
            System.out.println("Process Temperature [K]: " + procTemp);
            System.out.println("Rotational Speed [rpm]: " + rotSpeed);
            System.out.println("Torque [Nm]: " + torque);
            System.out.println("Tool Wear [min]: " + toolWear);
            System.out.println(newLine + "Index of predicted class label: " + result + ", which corresponds to class: " + classes.get(Double.valueOf(result).intValue()) + newLine);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
